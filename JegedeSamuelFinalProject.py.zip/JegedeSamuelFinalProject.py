import tkinter
from tkinter import *

root=Tk()
root.title("Grade Calculator")
root.geometry ("500x400")

def Calculation(): #calculation parameters
    english=int(englishentry.get())
    chemistry=int(chemistryentry.get())
    physics=int(physicsentry.get())
    total=(english+chemistry+physics)
    Label(text=f"{total}",font="arial 15 bold").place(x=250,y=170)

    average=int(total/3)
    Label(text=f"{average}",font="arial 15 bold").place(x=250,y=210)

    if (average>60):
        grade="PASS"
    else:
        grade="FAIL"

    Label(text=f"{grade}",font="arial 15 bold", fg="blue").place(x=250,y=250)





#subject taken by the students (the subjects can be increased, it depends on the teacher)
sub1=Label(root,text="English:",font="arial 11")
sub2=Label(root,text="Chemistry:",font="arial 11")
sub3=Label(root,text="Physics:",font="arial 11")
total=Label(root,text="Total:",font="arial 11")
average=Label(root,text="Average:",font="arial 11")
grade=Label(root,text="Grade:",font="arial 11")

#placements and positions
sub1.place(x=50,y=20)
sub2.place(x=50,y=70)
sub3.place(x=50,y=120)
total.place(x=50,y=170)
average.place(x=50,y=210)
grade.place(x=50,y=250)

#placements and positions of figure entries
englishvalue=StringVar()
chemistryvalue=StringVar()
physicsvalue=StringVar()

englishentry=Entry(root, textvariable=englishvalue, font="arial 15",width=15)
chemistryentry=Entry(root, textvariable=chemistryvalue, font="arial 15",width=15)
physicsentry=Entry(root, textvariable=physicsvalue, font="arial 15",width=15)

englishentry.place(x=250,y=20)
chemistryentry.place(x=250,y=70)
physicsentry.place(x=250,y=120)

#Buttons
Button(text="Calculate",font="arial 15", bg="white",bd=10, command=Calculation).place(x=50,y=300)
Button(text="Exit",font="arial 15", bg="white",bd=10,width=8,command=lambda:exit()).place(x=350,y=300)




root.mainloop()


